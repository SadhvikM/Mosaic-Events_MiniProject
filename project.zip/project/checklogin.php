<?php
if(!isset($_SESSION['rainbow_username']))
echo '<script type="text/javascript">window.location="login.php"; </script>';
?>